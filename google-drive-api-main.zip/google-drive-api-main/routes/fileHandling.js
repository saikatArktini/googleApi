import express from 'express';
import { copyfile, listFiles,uploadFile,isFolderShared,deleteFile_fold,createFile,copyFileWithoutPath,fetchFiles,fetchFilesCat,fetchTable,pushDb,fetchReplicaLink } from '../controllers/fileHandlingController.js';
import multer from 'multer';
//import multerConfig from '../middlewares/multerconfig.js';
const router = express.Router();
const upload = multer({
    dest: '../uploads/', // upload folder
    limits: { fieldSize: 10000000 }, // 10MB
  });

router.post('/copyFile/:fileId/:destinationFolderId', copyfile);
router.get('/listFiles/:folderId', listFiles);
router.post('/upload-file/:folderId', upload.single('filePath'),uploadFile);
router.get('/isFolderShared/:folderId/:destinationFolderId', isFolderShared);
//router.delete('/deleteFile_fold/:id', deleteFile_fold);
router.post('/createFile/:folderId/:fileName', createFile);
router.post('/copyFileWithoutPath/:fileId/:destinationFolderId', copyFileWithoutPath);
router.get('/fetchFiles/:url', fetchFiles);
router.get('/fetchFilesCategory/:category/:url', fetchFilesCat);
router.get('/fetchTable/:table', fetchTable);
router.post('/pushDb', pushDb);
router.get('/fetchReplicaLink',fetchReplicaLink);
export default router;