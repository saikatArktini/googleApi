// import cron from 'node-cron';
// import axios from 'axios';
// import express from 'express';

// const router = express.Router();

// const LIST_FILES_API = `http://localhost:9000/api/drive/folder/listFolders`;
// const COPY_FILE_API = `http://localhost:9000/api/drive/file/copyFile`;
// const COPY_FOLDER_API = `http://localhost:9000/api/drive/folder/copyFolder`;

// const NUM_JOBS = 3;
// const CHUNK_SIZE = 15;

// let isProcessing = false;
// let processedDrives = [];
// let BACKGROUND_JOBS = [];
// let completedChunks = 0;
// // let flag = 1

// router.post('/move-folder', async (req, res) => {
//     try {
//         console.log("Received request to move folder.");

//         if (isProcessing) {
//             console.log("Folder move operation is already in progress.");
//             return res.status(200).json({
//                 message: 'Folder move operation is already in progress.',
//                 status: { completedChunks },
//             });
//         }

//         const { folderId, tempDrives } = req.body;

//         if (!folderId) {
//             console.error("Folder ID is missing in the request.");
//             return res.status(400).json({ error: 'Folder ID is required.' });
//         }

//         if (!tempDrives || tempDrives.length < NUM_JOBS) {
//             console.error(`Invalid drives. Received: ${tempDrives?.length || 0}`);
//             return res.status(400).json({ error: `At least ${NUM_JOBS} temporary drives are required.` });
//         }

//         isProcessing = true;
//         console.log(`Starting folder move for folder ID: ${folderId} with ${tempDrives.length} drives.`);

//         const fileListResponse = await axios.get(`${LIST_FILES_API}/${folderId}`);
//         console.log("File list API response received.", fileListResponse.data);

//         const files = fileListResponse?.data;
//         if (!files || files.length === 0) {
//             console.error("No files found in the folder.");
//             isProcessing = false;
//             return res.status(200).json({ message: 'No files found in the folder to move.' });
//         }

//         console.log(`Total files retrieved: ${files.length}`);

//         const fileChunks = [];
//         for (let i = 0; i < files.length; i += CHUNK_SIZE) {
//             fileChunks.push(files.slice(i, i + CHUNK_SIZE));
//         }

//         console.log(`Total Chunks Created: ${fileChunks.length}`);
//         fileChunks.forEach((chunk, idx) => console.log(`Chunk ${idx + 1}: ${chunk.length} files`));

//         await processChunks(folderId, tempDrives, fileChunks);

//         res.status(200).json({
//             message: `Jobs scheduled to move files from folder ${folderId} in chunks.`,
//             status: { completedChunks },
//         });
//     } catch (error) {
//         console.error('Error in move-folder operation:', error.message);
//         res.status(500).send('Failed to start folder move operation.');
//     }
// });

// async function processChunks(folderId, tempDrives, fileChunks) {
//     for (const chunk of fileChunks) {
//         const selectedDrives = tempDrives.sort(() => 0.5 - Math.random()).slice(0, NUM_JOBS);
//         console.log(`Processing chunk with ${chunk.length} files using drives: ${selectedDrives.join(', ')}`);
//         await processChunk(folderId, chunk, selectedDrives);
//         completedChunks++;
//         console.log(`Completed chunk ${completedChunks}/${fileChunks.length}`);
//     }
//     console.log('All chunks processed. Folder move operation finished.');
//     isProcessing = false;
// }

// function processChunk(folderId, chunk, selectedDrives) {
//     return new Promise((resolve) => {
//         let activeJobs = selectedDrives.length; // Number of drives to process
//         let completedJobs = 0; // Counter to track the completed jobs per chunk
//         const localBackgroundJobs = [];
//         let completedFiles = 0;
//         const fileResultsMap = new Map();

//         selectedDrives.forEach((drive, index) => {
//             console.log(`Job ${index + 1}: Scheduled to move chunk to drive "${drive.name}"`);

//             const fileQueue = [...chunk];
//             const jobKey = `${drive.name}-${folderId}`;
//             let isJobStopped = false;

//             const job = cron.schedule('*/1 * * * * *', async () => {
//                 if (fileQueue.length === 0 && !isJobStopped) {
//                     console.log(`Job ${index + 1}: All files processed for drive "${drive.name}". Stopping job.`);
//                     isJobStopped = true; // Mark this job as stopped
//                     job.stop();

//                     // Remove the job from the local background job list
//                     const jobIndex = localBackgroundJobs.findIndex((j) => j.key === jobKey);
//                     if (jobIndex > -1) localBackgroundJobs.splice(jobIndex, 1);

//                     // Remove from global job tracking as well
//                     const globalJobIndex = BACKGROUND_JOBS.findIndex((j) => j.key === jobKey);
//                     if (globalJobIndex > -1) BACKGROUND_JOBS.splice(globalJobIndex, 1);

//                     if (completedJobs === activeJobs) {
//                         // flag = 1;
//                         // console.log("flag value after", flag)
//                         console.log('completed jobs after', completedJobs)
//                         console.log(`All jobs completed for chunk on folder ${folderId}`);
//                         console.log("paths are", paths)
//                         resolve();
//                     }
//                     return;
//                 }

//                 if (fileQueue.length > 0) {
//                     const file = fileQueue.shift();
//                     try {
//                         const API = file.type === 'file' ? COPY_FILE_API : COPY_FOLDER_API;
//                         console.log(`Copying ${file.type} "${file.name}" to drive "${drive.name}"`);
//                         const response = await axios.post(`${API}/${file.id}/${drive.folderId}`);
//                         if (response.status === 200) {
//                             console.log(`Successfully copied ${file.type} "${file.name}" to drive "${drive.name}"`);
//                             console.log("paths are", response.data.path)
//                             // console.log("rlink are", response.data.data.webViewLink)
//                             // console.log('flag value initially', flag)
//                             // console.log('completed jobs initially', completedJobs)
//                             if (!fileResultsMap.has(file.id)) {
//                                 fileResultsMap.set(file.id, { repLinks: [], processedDrives: 0 });
//                             }
//                             const fileResult = fileResultsMap.get(file.id);
//                             fileResult.repLinks[index] = {
//                                 link: response.data.data.webViewLink,
//                                 path: response.data.path,
//                                 locationID: response.data.locationId || drive.folderId
//                             };
//                             fileResult.processedDrives++;
//                             if (fileResult.processedDrives === selectedDrives.length) {
//                                 console.log('154',fileResult)
//                                 await axios.post('http://localhost:3000/api/assetLink/assetBackupLink', {
//                                     orgLink: file.link,
//                                     orgId: file.id,
//                                     repLink1: [fileResult.repLinks[0]],
//                                     repLink2: [fileResult.repLinks[1]],
//                                     repLink3: [fileResult.repLinks[2]],
//                                     driveInfo: { selectedDrives },
//                                 });
//                                 console.log(`API called for file "${file.name}"`);
//                                 completedFiles++;
//                             }

//                         } else {
//                             console.error(`Failed to copy ${file.type} "${file.name}" to drive "${drive.name}"`);
//                         }
//                     } catch (error) {
//                         console.error(`Error copying ${file.type} "${file.name}": ${error.message}`);
//                     }
//                 }
//             });

//             job.key = jobKey;
//             localBackgroundJobs.push(job);
//             BACKGROUND_JOBS.push(job);
//             job.start();
//         });
//     });
// }


// router.get('/job-status', (req, res) => {
//     res.status(200).json({
//         isProcessing,
//         completedJobs,
//         totalJobs: NUM_JOBS,
//         processedDrives,
//     });
// });

// export default router;



// if (fileQueue.length > 0) {
//     const file = fileQueue.shift();
//     try {
//         const API = file.type === 'file' ? COPY_FILE_API : COPY_FOLDER_API;
//         console.log(`Copying ${file.type} "${file.name}" to drive "${drive.name}"`);

//         const response = await axios.post(`${API}/${file.id}/${drive.folderId}`);

//         if (response.status === 200) {
//             console.log(`Successfully copied ${file.type} "${file.name}" to drive "${drive.name}"`);
//             console.log("Paths are", response.data.path);

//             // If file.type is file, we can handle it simply
//             if (file.type === 'file') {
//                 console.log("File data response:", response);

//                 if (!fileResultsMap.has(file.id)) {
//                     fileResultsMap.set(file.id, { repLinks: [], processedDrives: 0 });
//                 }
//                 const fileResult = fileResultsMap.get(file.id);

//                 // Store the result for this file
//                 fileResult.repLinks[index] = {
//                     link: response.data.data.webViewLink, 
//                     path: response.data.path,
//                     locationID: response.data.locationId || drive.folderId
//                 };
//                 fileResult.processedDrives++;

//                 // If all drives have been processed for this file, make the backup call
//                 if (fileResult.processedDrives === selectedDrives.length) {
//                     await axios.post('http://localhost:3000/api/assetLink/assetBackupLink', {
//                         orgLink: file.link,
//                         orgId: file.id,
//                         repLink1: [fileResult.repLinks[0]],
//                         repLink2: [fileResult.repLinks[1]],
//                         repLink3: [fileResult.repLinks[2]],
//                         driveInfo: { selectedDrives },
//                     });
//                     console.log(`API called for file "${file.name}"`);
//                     completedFiles++;
//                 }
//             }
//             // If file.type is folder, we need to process each item in the paths array
//             else if (file.type === 'folder' && Array.isArray(response.data.path)) {
//                 console.log("Folder data response:", response);

//                 if (!fileResultsMap.has(file.id)) {
//                     fileResultsMap.set(file.id, { repLinks: [], processedDrives: 0 });
//                 }
//                 const fileResult = fileResultsMap.get(file.id);

//                 // Iterate through the array inside 'paths' for each file object inside the folder
//                 for (let i = 0; i < response.data.path.length; i++) {
//                     const pathItem = response.data.path[i];
//                     // Assuming 'index' is the current index for the drive
//                     fileResult.repLinks[index] = {
//                         link: pathItem.copiedLink,
//                         path: pathItem.path,
//                         locationID: pathItem.copiedId || drive.folderId
//                     };

//                     // Increment processed drives for each file inside the folder
//                     fileResult.processedDrives++;

//                     // If all drives have been processed for this folder, make the backup call
//                     if (fileResult.processedDrives === selectedDrives.length * response.data.path.length) {
//                         await axios.post('http://localhost:3000/api/assetLink/assetBackupLink', {
//                             orgLink: file.link,
//                             orgId: file.id,
//                             repLink1: [fileResult.repLinks[0]],
//                             repLink2: [fileResult.repLinks[1]],
//                             repLink3: [fileResult.repLinks[2]],
//                             driveInfo: { selectedDrives },
//                         });
//                         console.log(`API called for folder "${file.name}"`);
//                         completedFiles++;
//                     }
//                 }
//             }
//         } else {
//             console.error(`Failed to copy ${file.type} "${file.name}" to drive "${drive.name}"`);
//         }
//     } catch (error) {
//         console.error(`Error copying ${file.type} "${file.name}": ${error.message}`);
//     }
// }




import cron from 'node-cron';
import axios from 'axios';
import express from 'express';

const router = express.Router();

const LIST_FILES_API = `http://localhost:9000/api/drive/folder/listFolders`;
const COPY_FILE_API = `http://localhost:9000/api/drive/file/copyFile`;
const COPY_FOLDER_API = `http://localhost:9000/api/drive/folder/copyFolder`;

const NUM_JOBS = 3;
const CHUNK_SIZE = 15;

let isProcessing = false;
let processedDrives = [];
let BACKGROUND_JOBS = [];
let completedChunks = 0;
// let flag = 1

router.post('/move-folder', async (req, res) => {
    try {
        console.log("Received request to move folder.");

        if (isProcessing) {
            console.log("Folder move operation is already in progress.");
            return res.status(200).json({
                message: 'Folder move operation is already in progress.',
                status: { completedChunks },
            });
        }

        const { folderId, tempDrives } = req.body;

        if (!folderId) {
            console.error("Folder ID is missing in the request.");
            return res.status(400).json({ error: 'Folder ID is required.' });
        }

        if (!tempDrives || tempDrives.length < NUM_JOBS) {
            console.error(`Invalid drives. Received: ${tempDrives?.length || 0}`);
            return res.status(400).json({ error: `At least ${NUM_JOBS} temporary drives are required.` });
        }

        isProcessing = true;
        console.log(`Starting folder move for folder ID: ${folderId} with ${tempDrives.length} drives.`);

        const fileListResponse = await axios.get(`${LIST_FILES_API}/${folderId}`);
        console.log("File list API response received.", fileListResponse.data);

        const files = fileListResponse?.data;
        if (!files || files.length === 0) {
            console.error("No files found in the folder.");
            isProcessing = false;
            return res.status(200).json({ message: 'No files found in the folder to move.' });
        }

        console.log(`Total files retrieved: ${files.length}`);

        const fileChunks = [];
        for (let i = 0; i < files.length; i += CHUNK_SIZE) {
            fileChunks.push(files.slice(i, i + CHUNK_SIZE));
        }

        console.log(`Total Chunks Created: ${fileChunks.length}`);
        fileChunks.forEach((chunk, idx) => console.log(`Chunk ${idx + 1}: ${chunk.length} files`));

        await processChunks(folderId, tempDrives, fileChunks);

        res.status(200).json({
            message: `Jobs scheduled to move files from folder ${folderId} in chunks.`,
            status: { completedChunks },
        });
    } catch (error) {
        console.error('Error in move-folder operation:', error.message);
        res.status(500).send('Failed to start folder move operation.');
    }
});

async function processChunks(folderId, tempDrives, fileChunks) {
    for (const chunk of fileChunks) {
        const selectedDrives = tempDrives.sort(() => 0.5 - Math.random()).slice(0, NUM_JOBS);
        console.log(`Processing chunk with ${chunk.length} files using drives: ${selectedDrives.join(', ')}`);
        await processChunk(folderId, chunk, selectedDrives);
        completedChunks++;
        console.log(`Completed chunk ${completedChunks}/${fileChunks.length}`);
    }
    console.log('All chunks processed. Folder move operation finished.');
    isProcessing = false;
}

function processChunk(folderId, chunk, selectedDrives) {
    return new Promise((resolve) => {
        let activeJobs = selectedDrives.length; // Number of drives to process
        let completedJobs = 0; // Counter to track the completed jobs per chunk
        const localBackgroundJobs = [];
        let completedFiles = 0;
        const fileResultsMap = new Map();

        selectedDrives.forEach((drive, index) => {
            console.log(`Job ${index + 1}: Scheduled to move chunk to drive "${drive.name}"`);

            const fileQueue = [...chunk];
            const jobKey = `${drive.name}-${folderId}`;
            let isJobStopped = false;

            const job = cron.schedule('*/1 * * * * *', async () => {
                if (fileQueue.length === 0 && !isJobStopped) {
                    console.log(`Job ${index + 1}: All files processed for drive "${drive.name}". Stopping job.`);
                    isJobStopped = true; // Mark this job as stopped
                    job.stop();

                    // Remove the job from the local background job list
                    const jobIndex = localBackgroundJobs.findIndex((j) => j.key === jobKey);
                    if (jobIndex > -1) localBackgroundJobs.splice(jobIndex, 1);

                    // Remove from global job tracking as well
                    const globalJobIndex = BACKGROUND_JOBS.findIndex((j) => j.key === jobKey);
                    if (globalJobIndex > -1) BACKGROUND_JOBS.splice(globalJobIndex, 1);

                    if (completedJobs === activeJobs) {
                        // flag = 1;
                        // console.log("flag value after", flag)
                        console.log('completed jobs after', completedJobs)
                        console.log(`All jobs completed for chunk on folder ${folderId}`);
                        console.log("paths are", paths)
                        resolve();
                    }
                    return;
                }

                if (fileQueue.length > 0) {
                    const file = fileQueue.shift();
                    try {
                        const API = file.type === 'file' ? COPY_FILE_API : COPY_FOLDER_API;
                        console.log(`Copying ${file.type} "${file.name}" to drive "${drive.name}"`);

                        const response = await axios.post(`${API}/${file.id}/${drive.folderId}`);

                        if (response.status === 200) {
                            console.log(`Successfully copied ${file.type} "${file.name}" to drive "${drive.name}"`);
                            console.log("Paths are", response.data.path);

                            // If file.type is file, we can handle it simply
                            if (file.type === 'file') {
                                console.log("File data response:", response);

                                if (!fileResultsMap.has(file.id)) {
                                    fileResultsMap.set(file.id, { repLinks: [], processedDrives: 0 });
                                }
                                const fileResult = fileResultsMap.get(file.id);

                                // Store the result for this file
                                fileResult.repLinks[index] = {
                                    link: response.data.data.webViewLink,
                                    path: response.data.path,
                                    locationID: response.data.locationId || drive.folderId
                                };
                                fileResult.processedDrives++;

                                if (fileResult.processedDrives === selectedDrives.length) {
                                    await axios.post('http://localhost:3000/api/assetLink/assetBackupLink', {
                                        orgLink: file.link,
                                        orgId: file.id,
                                        repLink1: [fileResult.repLinks[0]],
                                        repLink2: [fileResult.repLinks[1]],
                                        repLink3: [fileResult.repLinks[2]],
                                        driveInfo: { selectedDrives },
                                    });
                                    console.log(`API called for file "${file.name}"`);
                                    completedFiles++;
                                }
                            }
                            else if (file.type === 'folder' && Array.isArray(response.data.path)) {
                                console.log("Folder data response:", response);

                                if (!fileResultsMap.has(file.id)) {
                                    fileResultsMap.set(file.id, { repLinks: [], processedDrives: 0 });
                                }
                                const fileResult = fileResultsMap.get(file.id);

                                // Iterate through the array inside 'paths' for each file object inside the folder
                                for (let i = 0; i < response.data.path.length; i++) {
                                    const pathItem = response.data.path[i];

                                    // Store the result for this specific item
                                    fileResult.repLinks[index] = {
                                        link: pathItem.copiedLink,
                                        path: pathItem.path,
                                        locationID: pathItem.copiedId || drive.folderId
                                    };

                                    console.log('480',fileResult)

                                    // Make the backup call for each item inside the folder
                                    await axios.post('http://localhost:3000/api/assetLink/assetBackupLink', {
                                        orgLink: pathItem.orgLink,
                                        orgId: pathItem.id,
                                        repLink1: [fileResult.repLinks[0]],
                                        repLink2: [fileResult.repLinks[1]],
                                        repLink3: [fileResult.repLinks[2]],
                                        driveInfo: { selectedDrives },
                                    });
                                    // Store the result for this specific item
                                    fileResult.repLinks[index] = {
                                        link: null,
                                        path: null,
                                        locationID: null
                                    };
                                    console.log(`API called for folder item ${pathItem.name}`);
                                    completedFiles++;
                                }
                            }


                        } else {
                            console.error(`Failed to copy ${file.type} "${file.name}" to drive "${drive.name}"`);
                        }
                    } catch (error) {
                        console.error(`Error copying ${file.type} "${file.name}": ${error.message}`);
                    }
                }


            });

            job.key = jobKey;
            localBackgroundJobs.push(job);
            BACKGROUND_JOBS.push(job);
            job.start();
        });
    });
}


router.get('/job-status', (req, res) => {
    res.status(200).json({
        isProcessing,
        completedJobs,
        totalJobs: NUM_JOBS,
        processedDrives,
    });
});

export default router;





// else if (file.type === 'folder' && Array.isArray(response.data.path)) {
//     console.log("Folder data response:", response);

//     if (!fileResultsMap.has(file.id)) {
//         fileResultsMap.set(file.id, { repLinks: [], processedDrives: 0 });
//     }
//     const fileResult = fileResultsMap.get(file.id);

//     // Iterate through the array inside 'paths' for each file object inside the folder
//     for (let i = 0; i < response.data.path.length; i++) {
//         const pathItem = response.data.path[i];

//         // Store the result for this specific item
//         fileResult.repLinks[index] = {
//             link: pathItem.copiedLink,
//             path: pathItem.path,
//             locationID: pathItem.copiedId || drive.folderId
//         };

//         // Make the backup call for each item inside the folder
//         await axios.post('http://localhost:3000/api/assetLink/assetBackupLink', {
//             orgLink: file.link,
//             orgId: file.id,
//             repLink1: [fileResult.repLinks[0]],
//             repLink2: [fileResult.repLinks[1]],
//             repLink3: [fileResult.repLinks[2]],
//             driveInfo: { selectedDrives },
//         });

//         console.log(`API called for folder item ${pathItem.name}`);
//         completedFiles++;
//     }
// } 