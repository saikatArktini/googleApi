import express from 'express';
//import multerConfig from '../middlewares/multerconfig.js';
import { deleteFile_fold,renameFile_fold,checkHealth } from '../controllers/fileHandlingController.js';
const router = express.Router();
// router.get('/list-files/:folderId', listFiles);
// router.post('/upload-file/:folderId', multerConfig.single('file'),uploadFile);
// router.get('/download-file/:fileId', downloadFile);
router.delete('/deleteFile_fold/:id', deleteFile_fold);
router.put('/renameFile_fold/:id/:newFileName', renameFile_fold);
router.get('/checkHealth/:id', checkHealth);


router.post('/item/copy/:sourceDriveId/:itemId/:destinationDriveId', async (req, res) => {
    const { sourceDriveId, itemId, destinationDriveId } = req.params;

    try {
        const result = await copyItemToDrive(sourceDriveId, itemId, destinationDriveId);

        if (!result.success) {
            return res.status(400).json({ status: 'error', message: result.message });
        }

        res.status(200).json({
            status: 'success',
            message: 'Item copied successfully.',
            itemId,
            sourceDriveId,
            destinationDriveId,
        });
    } catch (error) {
        console.error('Error copying item:', error);
        res.status(500).json({ status: 'error', message: 'Failed to copy item.' });
    }
});

async function copyItemToDrive(sourceDriveId, itemId, destinationDriveId) {
    const isFile = itemId.startsWith('file');
    if (isFile) {
        console.log(`Copying file ${itemId} from drive ${sourceDriveId} to ${destinationDriveId}`);
    } else {
        console.log(`Copying folder ${itemId} from drive ${sourceDriveId} to ${destinationDriveId}`);
    }

    // Simulated result
    return { success: true };
}



export default router;  
