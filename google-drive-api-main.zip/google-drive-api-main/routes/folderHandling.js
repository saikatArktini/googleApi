import express from 'express';
import { copyFolder,listFolders, uploadFolder,createFolder } from '../controllers/folderHandlingController.js';
import multer from 'multer';
const router = express.Router();
const upload = multer({
    dest: '../uploads/',
    limits: { fieldSize: 10000000 },
  });

router.post('/copyFolder/:folderId/:destinationFolderId', copyFolder);
router.get('/listFolders/:folderId', listFolders);
router.post('/uploadFolder/:folderId',upload.single('folderPath'),uploadFolder);
router.post('/createFolder/:folderId/:folderName', createFolder);


export default router;