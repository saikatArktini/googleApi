const { google } = require('googleapis');
const { readFileSync } = require('fs');

// Load service account credentials
const SCOPES = ['https://www.googleapis.com/auth/drive'];
const SERVICE_ACCOUNT_FILE = "./driveapi-442105-fbfe01969fc6.json"

const auth = new google.auth.GoogleAuth({
  keyFile: SERVICE_ACCOUNT_FILE,
  scopes: SCOPES,
});

const drive = google.drive({ version: 'v3', auth });

module.exports = drive;
