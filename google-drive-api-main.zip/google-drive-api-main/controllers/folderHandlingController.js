import { google } from "googleapis";
import multer from "multer";
import express from "express";
// import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import { PassThrough } from "stream";
import { log } from "console";
import unzipper from "unzipper";
const __dirname = new URL('.', import.meta.url).pathname;
const serviceAccountKey = JSON.parse(fs.readFileSync("transdata-442208-31d212320cc2.json"));
const auth = new google.auth.GoogleAuth({
    credentials: serviceAccountKey,
    scopes: ["https://www.googleapis.com/auth/drive"],
});

export const copyFolder = async (req, res) => {
    // const drive = google.drive({ version: 'v3', auth });
    // const { folderId, destinationFolderId } = req.params;
    // if (!folderId || !destinationFolderId) {
    //     return res.status(400).send({ error: 'folderId and destinationFolderId are required' });
    // }
    // else{
    //     try {
    //         const response = await drive.files.get({
    //             fileId: folderId,
    //             fields: "id, name, parents, mimeType"
    //         })
    //         if(response.data.mimeType === "application/vnd.google-apps.folder"){
    //             const result = await copyFolderContents(folderId, destinationFolderId, drive);
    //             res.status(200).send(result);
    //             console.log("Copied folder contents:",result);
    //         }
    //         else{
    //             res.status(400).send("Please provide folder type that u want to copy");
    //             console.log("Please provide folder type that u want to copy");
    //         }
    //     } catch (error) {
    //         console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check:", error.message);
    //         res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check: ${error.message}`);
    //     }
    // }
    const drive = google.drive({ version: 'v3', auth });
    const { folderId, destinationFolderId } = req.params;
    var subFolder, subFolder2;
    if (!folderId || !destinationFolderId) {
        return res.status(400).send({ error: 'folderId and destinationFolderId are required' });
    }
    else{
        try {
            subFolder2 = await drive.files.get({
                fileId: folderId,
                fields: "id, name, parents,webViewLink, mimeType",
            });
            if (subFolder2.data.parents) {
            try {
                const parents = []
                let curPath='';
                const child=[];
                var subFolder1, response;
                await makeFolder(folderId, parents);
                subFolder1 = await drive.files.get({
                    fileId: destinationFolderId,
                    fields: "id, name, mimeType",
                })
                //parents.push(subFolder1.data);
                //console.log("@@@@",subFolder.data);
                subFolder = await drive.files.create({
                    requestBody: {
                        name: parents[parents.length - 1].name,
                        mimeType: parents[parents.length - 1].mimeType,
                        parents: [destinationFolderId]
                    }
                })
                console.log("73",subFolder.data.id);
                curPath=curPath+subFolder.data.name;
                const location=subFolder.data.id;
                for (var i = parents.length - 2; i >= 0; i--) {
                    console.log(subFolder.data.id);
                    subFolder = await drive.files.create({
                        requestBody: {
                            name: parents[i].name,
                            mimeType: parents[i].mimeType,
                            parents: [subFolder.data.id]
                        }
                    })
                    console.log(`created subfolder: ${subFolder.data.name}`);
                    curPath=curPath+"/"+subFolder.data.name;
                }
                console.log("89",curPath);
                try {
                    const response = await drive.files.get({
                        fileId: folderId,
                        fields: "id, name, parents, mimeType"
                    })
                    if(response.data.mimeType === "application/vnd.google-apps.folder"){
                        const subFolder5 = await drive.files.create({
                            requestBody: {
                                name: subFolder2.data.name,
                                mimeType: subFolder2.data.mimeType,
                                parents: [subFolder.data.id]
                            }
                        })
                        curPath=curPath+"/"+response.data.name;
                        //console.log("98:",subFolder5.data.mimeType);
                        console.log("88",curPath);
                        const result = await copyFolderContents(folderId, subFolder5.data.id, drive,curPath);
                        //res.status(200).send(result);
                        //console.log("Copied folder contents:",result);
                        const filesDetails = result.filter((i) => i.type === "file")
                        console.log("fileDetails", filesDetails);
                        const newFile = await drive.files.get({
                                fileId: subFolder.data.id,
                                fields: "id,name,webViewLink,mimeType"
                            })
                        
                            //console.log("67", newFile.data);
                            res.status(200).send({ message: "File copied successfully", path: filesDetails || [] });
                    }
                    else{
                        res.status(400).send("Please provide folder type that u want to copy");
                        console.log("Please provide folder type that u want to copy");
                    }
                } catch (error) {
                    console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check:", error.message);
                    res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check: ${error.message}`);
                }
                // const copiedFile = await drive.files.copy({
                //     fileId: folderId,
                //     requestBody: {
                //         name: subFolder2.data.name,
                //         parents: [subFolder.data.id],
                //         fields: "id",
                //     },
                // });
                // const newFile = await drive.files.get({
                //     fileId: copiedFile.data.id,
                //     fields: "id,name,webViewLink,mimeType"
                // })
                // console.log("67", newFile.data);
                // console.log(copiedFile.data);
                // res.status(200).send({ message: "File copied successfully", data: {...copiedFile.data,path:parents}});
                //res.status(200).send({ message: "File copied successfully", path: parents || [], data: newFile.data });
            } catch (err) {
                res.status(500).send({ message: "Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file.Error copying file", error: err.message });
                console.log("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error during folder share check:", err);
            }
            }
            else
            {
                try {
                    const response = await drive.files.get({
                        fileId: folderId,
                        fields: "id, name, parents, mimeType"
                    })
                    if(response.data.mimeType === "application/vnd.google-apps.folder"){
                        const subFolder5 = await drive.files.create({
                            requestBody: {
                                name: subFolder2.data.name,
                                mimeType: subFolder2.data.mimeType,
                                parents: [destinationFolderId]
                            }
                        })
                        const result = await copyFolderContents(folderId, subFolder5.data.id, drive);
                        res.status(200).send(result);
                        console.log("Copied folder contents:",result);
                    }
                    else{
                        res.status(400).send("Please provide folder type that u want to copy");
                        console.log("Please provide folder type that u want to copy");
                    }
                } catch (error) {
                    console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check:", error.message);
                    res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check: ${error.message}`);
                }

            }
        }
        catch (error) {
            console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check:", error.message);
            res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check: ${error.message}`);
        }
        // try {
        //     const response = await drive.files.get({
        //         fileId: folderId,
        //         fields: "id, name, parents, mimeType"
        //     })
        //     if(response.data.mimeType === "application/vnd.google-apps.folder"){
        //         const result = await copyFolderContents(folderId, destinationFolderId, drive);
        //         res.status(200).send(result);
        //         console.log("Copied folder contents:",result);
        //     }
        //     else{
        //         res.status(400).send("Please provide folder type that u want to copy");
        //         console.log("Please provide folder type that u want to copy");
        //     }
        // } catch (error) {
        //     console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check:", error.message);
        //     res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source folder. Error during folder share check: ${error.message}`);
        // }
    }
};
const makeFolder = async (id, parents) => {
    const drive = google.drive({ version: 'v3', auth });
    const response = await drive.files.get({
        fileId: id,
        fields: "id, name, parents, mimeType",
    })
    //console.log(response.data.parents);
    if (response.data.parents) {
        const response1 = await drive.files.get({
            fileId: response.data.parents,
            fields: "name,id,mimeType",
        })
        //console.log(response1.data);
        parents.push(response1.data);

    }

    if (response.data.parents) {
        await makeFolder(response.data.parents, parents);
    }
}

// async function copyFolderContents(folderId, destinationFolderId, drive,child) {
//     try {
//         // Get folder contents
//         const response = await drive.files.list({
//             q: `'${folderId}' in parents and trashed = false`,
//             fields: 'files(id, name, mimeType)',
//         });

//         const files = response.data.files;

//         for (const file of files) {
//             if (file.mimeType === 'application/vnd.google-apps.folder') {
//                 // If it's a folder, create a new folder in the destination and copy its contents
//                 const newFolder = await drive.files.create({
//                     requestBody: {
//                         name: file.name,
//                         mimeType: 'application/vnd.google-apps.folder',
//                         parents: [destinationFolderId],
//                     },
//                 });
                
//                 await copyFolderContents(file.id, newFolder.data.id, drive); // Recursively copy contents
//             } else {
//                 // If it's a file, copy the file to the destination
//                 await drive.files.copy({
//                     fileId: file.id,
//                     requestBody: {
//                         name: file.name,
//                         parents: [destinationFolderId],
//                     },
//                 });
//             }
//         }

//         return { message: 'Folder contents copied successfully' };
//     } catch (error) {
//         console.error('Error copying folder contents:', error);
//         throw new Error('Error copying folder contents');
//     }
// }
async function copyFolderContents(folderId, destinationFolderId, drive, parentPath = '') {
    try {
        // Fetch folder contents
        const response = await drive.files.list({
            q: `'${folderId}' in parents and trashed = false`,
            fields: 'files(id, name, mimeType)',
        });

        const files = response.data.files;
        const paths = []; // Array to store file paths
        const child=[];

        for (const file of files) {
            const currentPath = `${parentPath}/${file.name}`; // Construct the current path

            if (file.mimeType === 'application/vnd.google-apps.folder') {
                // If it's a folder, create a new folder in the destination and copy its contents
                const newFolder = await drive.files.create({
                    requestBody: {
                        name: file.name,
                        mimeType: 'application/vnd.google-apps.folder',
                        parents: [destinationFolderId],
                    },
                });

                // Store the folder path
                paths.push({ type: 'folder', id: file.id, name: file.name, path: currentPath });

                // Recursively copy contents and collect paths
                const subPaths = await copyFolderContents(
                    file.id,
                    newFolder.data.id,
                    drive,
                    currentPath
                );
                paths.push(...subPaths);
            } else {
                // If it's a file, copy the file to the destination
                const response=await drive.files.copy({
                    fileId: file.id,
                    requestBody: {
                        name: file.name,
                        parents: [destinationFolderId],
                    },
                });
                const orgLink = await drive.files.get({
                    fileId: file.id,
                    fields: 'id, name, webViewLink',
                })
                const copiedFile = await drive.files.get({
                    fileId: response.data.id,
                    fields: 'id, name, webViewLink',
                })
                // Store the file path
                paths.push({ type: 'file', id: file.id,name: file.name, orgLink: orgLink.data.webViewLink ,path: currentPath, copiedLink: copiedFile.data.webViewLink,copiedId:response.data.id,copiedName:response.data.name });
            }
        }

        return paths;
    } catch (error) {
        console.error('Error copying folder contents:', error);
        throw new Error('Error copying folder contents');
    }
}

export const listFolders = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { folderId } = req.params;

    try {
        if (folderId) {
            // Check if folderId is valid and is a folder
            const isFolder = await drive.files.get({
                fileId: folderId,
                fields: 'mimeType',
            });

            if (isFolder.data.mimeType === 'application/vnd.google-apps.folder') {
                console.log("Folder type is correct");

                // List files and include webViewLink
                const response = await drive.files.list({
                    q: `'${folderId}' in parents`,
                    fields: 'files(id, name, mimeType, webViewLink)',
                });

                // Add type and webViewLink to the response
                const filesWithType = response.data.files.map((file) => ({
                    id: file.id,
                    name: file.name,
                    type: file.mimeType === 'application/vnd.google-apps.folder' ? 'folder' : 'file',
                    link: file.webViewLink, // Add the link to the file or folder
                }));

                res.status(200).send(filesWithType);

                // Log folder and file links
                filesWithType.map((file) => {
                    console.log(`Name: ${file.name}, Link: ${file.link}`);
                });
            } else {
                console.log("Folder type is not correct");
                res.status(400).send("Please provide a valid folder ID");
            }
        } else {
            console.log("Please provide folderId");
            res.status(400).send("Please provide folderId");
        }
    } catch (error) {
        console.error(`Error listing folders: ${error.message}`);
        res.status(500).send(`Error listing folders: ${error.message}`);
    }
};


// export const listFolders = async (req, res) => { 
//     const drive = google.drive({ version: 'v3', auth });
//     const { folderId } = req.params;

//     try {
//         if (folderId) {
//             const isFolder = await drive.files.get({
//                 fileId: folderId
//             });
//             if (isFolder.data.mimeType === 'application/vnd.google-apps.folder') {
//                 console.log("Folder type is correct");
                
//                 const response = await drive.files.list({
//                     q: `'${folderId}' in parents`,
//                     fields: 'files(id, name, mimeType)',
//                 });

//                 // Add type based on mimeType
//                 const filesWithType = response.data.files.map((file) => ({
//                     id: file.id,
//                     name: file.name,
//                     type: file.mimeType === 'application/vnd.google-apps.folder' ? 'folder' : 'file',
//                 }));

//                 res.status(200).send(filesWithType);

//                 // Log folder links
//                 filesWithType.map((file) => {
//                     if (file.type === 'folder') {
//                         console.log(`https://drive.google.com/drive/u/2/folders/${file.id}`);
//                     }
//                 });
//             } else {
//                 console.log("Folder type is not correct");
//                 res.status(400).send("Please provide a folder ID");
//             }
//         } else {
//             console.log("Please provide folderId");
//             res.status(400).send("Please provide folderId");
//         }
//     } catch (error) {
//         res.status(500).send(`Error listing folders: ${error.message}`);
//     }
// };


// export const listFolders = async (req, res) => {
//     const drive = google.drive({ version: 'v3', auth });
//     const { folderId } = req.params;
//     try {
//         if (folderId) {
//             const isFolder = await drive.files.get({
//                 fileId: folderId
//             });
//             if (isFolder.data.mimeType == 'application/vnd.google-apps.folder') {
//                 console.log("Folder type is correct");
//                 const response = await drive.files.list({
//                     q: `'${folderId}' in parents`,
//                     fields: 'files(id, name)',
//                 });
//                 res.status(200).send(response.data.files);
//                 response.data.files.map((file) => {
//                     return (console.log(`https://drive.google.com/drive/u/2/folders/${file.id}`));
//                 })
//             }
//             else {
//                 console.log("Folder type is not correct");
//                 res.status(400).send("Please provide folder");
//             }
//         }
//         else {
//             console.log("Please provide folderId");
//             res.status(400).send("Please provide folderId");
//         }
//     } catch (error) {
//         res.status(500).send(`Error listing folders: ${error.message}`);
//     }
// }



export const uploadFolder = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    var { folderId } = req.params;
    const filePath = req.file.path;
    console.log(filePath, folderId);
    const folderName = req.file;
    console.log("==========",folderName);
    const folderPath = decodeURIComponent(path.normalize(path.join(__dirname, 'unzipped')).replace(/^\\/, ''));
    console.log("*", folderPath);
    const fileMetadata = {
        'name': folderName.originalname,
        mimeType: 'application/vnd.google-apps.folder',
        parents: [folderId]
    };
    const response = await drive.files.create({
        resource: fileMetadata,
        fields: 'id,name'
    });

    console.log("Folder created:",response.data);
    //res.status(200).send("File uploaded successfully");
    try {
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        await fs.createReadStream(filePath)
            .pipe(unzipper.Extract({ path: folderPath }))
            .promise();
        folderId = response.data.id;

        console.log("Unzip complete. Starting upload to Google Drive...");
        await uploadToDrive(drive,folderPath, folderId);

        res.status(200).send("All files uploaded successfully.");
    }
    catch (error) {
        console.error("Error uploading file:", error.message);
        res.status(500).send(`Error uploading file: ${error.message}`);
    }
    finally {
        //Clean up temporary files
       fs.rmSync(filePath,{ force: true });
        fs.rmSync(folderPath, { recursive: true, force: true });
    }
    
}
const uploadToDrive = async (drive,folderPath, parentFolderId) => {
    const items = fs.readdirSync(folderPath);
  
    for (const item of items) {
      const itemPath = path.join(folderPath, item);
  
      if (fs.lstatSync(itemPath).isDirectory()) {
        // Create a folder in Google Drive
        const folderMetadata = {
          name: item,
          mimeType: "application/vnd.google-apps.folder",
          parents: [parentFolderId],
        };
  
        const folderResponse = await drive.files.create({
          requestBody: folderMetadata,
          fields: "id",
        });
  
        const newFolderId = folderResponse.data.id;
        console.log(`Created folder: ${item} (ID: ${newFolderId})`);
  
        // Recursively upload the contents of the subfolder
        await uploadToDrive(drive,itemPath, newFolderId);
      } else {
        // Upload file to Google Drive
        const fileMetadata = {
          name: item,
          parents: [parentFolderId],
        };
  
        const media = {
          mimeType: "application/octet-stream",
          body: fs.createReadStream(itemPath),
        };
  
        const fileResponse = await drive.files.create({
          requestBody: fileMetadata,
          media,
          fields: "id",
        });
  
        console.log(`Uploaded file: ${item} (ID: ${fileResponse.data.id})`);
      }
    }
  };
  
export const createFolder = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { folderId, folderName } = req.params;
    try {
        if (folderId && folderName) {
            const fileMetadata = {
                'name': folderName,
                mimeType: 'application/vnd.google-apps.folder',
                parents: [folderId]
            };
            const response = await drive.files.create({
                resource: fileMetadata,
                fields: 'id,name'
            });
            res.status(200).send(`Folder created successfully. FolderId: ${response.data.name}`);
            console.log(response.data);
        }
        else {
            res.status(400).send("Please provide folderId and folderName");
            console.log("Please provide folderId and folderName");
        }
    } catch (error) {
        console.error("Error creating folder:", error.message);
        res.status(500).send(`Error creating folder: ${error.message}`);
    }
}
