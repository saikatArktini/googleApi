const drive = require('../googledrive');
const { readFileSync } = require('fs');

// List files in a folder
exports.listFiles = async (req, res) => {
  const { folderId } = req.params;
  try {
    const response = await drive.files.list({
      q: `'${folderId}' in parents`,
      fields: 'files(id, name)',
    });
    res.json(response.data.files);
  } catch (error) {
    res.status(500).send(`Error listing files: ${error.message}`);
  }
};

// Upload a new file
exports.uploadFile = async (req, res) => {
  const { folderId } = req.params;
  const filePath = req.file.path;
  const fileName = req.file.originalname;

  try {
    const response = await drive.files.create({
      requestBody: {
        name: fileName,
        parents: [folderId],
      },
      media: {
        mimeType: req.file.mimetype,
        body: readFileSync(filePath),
      },
    });
    res.json({ fileId: response.data.id });
  } catch (error) {
    res.status(500).send(`Error uploading file: ${error.message}`);
  }
};

// Download a file
exports.downloadFile = async (req, res) => {
  const { fileId } = req.params;
  try {
    const response = await drive.files.get(
      { fileId, alt: 'media' },
      { responseType: 'stream' }
    );
    response.data
      .on('end', () => {
        console.log('Downloaded file.');
      })
      .on('error', (err) => {
        console.error('Error downloading file:', err);
      })
      .pipe(res);
  } catch (error) {
    res.status(500).send(`Error downloading file: ${error.message}`);
  }
};
