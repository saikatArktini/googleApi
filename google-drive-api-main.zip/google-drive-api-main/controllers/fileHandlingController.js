import { google } from "googleapis";
import express from "express";
//import dotenv from "dotenv";
import fs from "fs";
import axios from "axios";
import path from "path";
import { PassThrough } from "stream";
import { log } from "console";
import exp from "constants";
const __dirname = new URL('.', import.meta.url).pathname;
const serviceAccountKey = JSON.parse(fs.readFileSync("transdata-442208-31d212320cc2.json"));
const auth = new google.auth.GoogleAuth({
    credentials: serviceAccountKey,
    scopes: ["https://www.googleapis.com/auth/drive"],
});
export const fetchFiles = async (req, res) => {
    try {
        var { url } = req.params;
    console.log("17",url);
    const response = await axios.post(`http://localhost:5000/api/asset/uploader`, {folderLink: url });
    console.log("20",response.data);
    res.json(response.data);
    } catch (error) {
        res.status(500).send(`Error fetching files: ${error.message}`);
    }
}
export const fetchFilesCat = async (req, res) => {
    try {
        var { category, url } = req.params;
        console.log("17",category);
        const folderPath = url.split("/");
        const fileId = folderPath[folderPath.length - 1];
        const assetList = await axios.get(
            `https://rj2.arktini.com/script/read/folder/${fileId}`
          );
          const folders = assetList.data.fileInfo.subfolders;
        const filteredFolders = folders.filter((f) => f.file.name.toLowerCase() === category.toLowerCase());
        res.json(filteredFolders);
    console.log("17",filteredFolders);
    
    } catch (error) {
        res.status(500).send(`Error fetching files: ${error.message}`);
    }
}
export const fetchTable = async (req, res) => {
    try {
        const{ table } = req.params;
        //console.log("48",table);
        const response= await axios.post(`http://localhost:5000/api/asset/uploader/getFiles/${table}`);
        console.log("50",response.data);
        res.json(response.data);
    }
    catch (error) {
            res.status(500).send(`Error fetching files: ${error.message}`);
    }
}
export const pushDb = async (req, res) => {
    try {
        const response= await axios.post(`http://localhost:5000/api/asset/uploader/push`);
        console.log("60",response.data);
        
        console.log("61",response);
        res.json(response.data);
    }
    catch (error) {
        if(error.response.status === 400){
            res.status(400).send(error.response.data);
        }
        else
            res.status(500).send(`Error Pushing files: ${error.message}`);
    }
}
export const fetchReplicaLink = async (req, res) => {
    try {
        const {url} = req.query;
      console.log("76",url);
        //const response= await axios.get(`http://localhost:3000/api/assetLink/assetRepBackupLink/${url}`);
        const response = await axios.get(`http://localhost:3000/api/assetLink/assetRepBackupLink?url=${encodeURIComponent(url)}`);
        console.log("77",response.data);    
        console.log("76",url);
        res.json(response.data);
    }
    catch (error) {
        res.status(500).send(`Error fetching files: ${error.message}`);
    }
}
export const copyfile = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    var { fileId, destinationFolderId } = req.params;
    var subFolder, subFolder2;
    try {
        subFolder2 = await drive.files.get({
            fileId: fileId,
            fields: "id, name, parents,webViewLink",
        });
        //console.log(subFolder.data.parents);
        if (subFolder2.data.parents) {
            try {
                const parents = [];
                var subFolder1, response;
                await makeFolder(fileId, parents);
                subFolder1 = await drive.files.get({
                    fileId: destinationFolderId,
                    fields: "id, name, mimeType",
                })
                //parents.push(subFolder1.data);
                //console.log("@@@@",subFolder.data);
                subFolder = await drive.files.create({
                    requestBody: {
                        name: parents[parents.length - 1].name,
                        mimeType: parents[parents.length - 1].mimeType,
                        parents: [destinationFolderId]
                    }
                })
                const locaton = subFolder.data.id
                for (var i = parents.length - 2; i >= 0; i--) {
                    console.log(subFolder.data.id);
                    subFolder = await drive.files.create({
                        requestBody: {
                            name: parents[i].name,
                            mimeType: parents[i].mimeType,
                            parents: [subFolder.data.id]
                        }
                    })
                    console.log(`created subfolder: ${subFolder.data.name}`);
                    //console.log("52",parents[i])
                }
                const copiedFile = await drive.files.copy({
                    fileId: fileId,
                    requestBody: {
                        name: subFolder2.data.name,
                        parents: [subFolder.data.id],
                        fields: "id",
                    },
                });
                const newFile = await drive.files.get({
                    fileId: copiedFile.data.id,
                    fields: "id,name,webViewLink,mimeType"
                })
                // console.log("67", newFile.data);
                // console.log(copiedFile.data);
                // res.status(200).send({ message: "File copied successfully", data: {...copiedFile.data,path:parents}});
                res.status(200).send({ message: "File copied successfully", path: parents || [], data: newFile.data, locationId:locaton});
            } catch (err) {
                res.status(500).send({ message: "Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file.Error copying file", error: err.message });
                console.log("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error during folder share check:", err);
            }
        }
        else {
            try {
                const copiedFile = await drive.files.copy({
                    fileId: fileId,
                    requestBody: {
                        name: subFolder2.data.name,
                        parents: [destinationFolderId],
                        fields: "id, webViewLink, name",
                    },

                });
                console.log(copiedFile.data);
                res.status(200).send({ message: "File copied successfully", data: copiedFile.data });
            } catch (err) {
                res.status(500).send({ message: "Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error copying file", error: err.message });
                console.log("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error during folder share check:", err);
            }
        }
    } catch (error) {
        console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error during folder share check:", error);
        res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file.Error during folder share check: ${error.message}`);
    }

}
// catch (error) {
//     console.error("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error during folder share check:", error.message);
//     res.status(500).send(`Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file.Error during folder share check: ${error.message}`);
// }
const makeFolder = async (id, parents) => {
    const drive = google.drive({ version: 'v3', auth });
    const response = await drive.files.get({
        fileId: id,
        fields: "id, name, parents, mimeType",
    })
    //console.log(response.data.parents);
    if (response.data.parents) {
        const response1 = await drive.files.get({
            fileId: response.data.parents,
            fields: "name,id,mimeType",
        })
        //console.log(response1.data);
        parents.push(response1.data);

    }

    if (response.data.parents) {
        await makeFolder(response.data.parents, parents);
    }
}
export const listFiles = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { folderId } = req.params;
    try {
        if (folderId) {
            const response = await drive.files.list({
                q: `'${folderId}' in parents`,
                fields: 'files(id, name, webViewLink)',
            });
            res.json(response.data.files);
        }
        else {
            console.log("Please provide folderId");
            res.status(400).send("Please provide folderId");
        }
    } catch (error) {
        res.status(500).send(`Error listing files: ${error.message}`);
    }
}


export const uploadFile = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { folderId } = req.params;
    const filePath = req.file.path;
    const originalname = req.file;
    try {
        if (folderId && filePath) {
            const fileName = path.basename(filePath);
            console.log(fileName);
            const fileStream = new PassThrough();
            const fileBuffer = fs.readFileSync(filePath);
            fileStream.end(fileBuffer);
            const response = await drive.files.create({
                requestBody: {
                    name: originalname.originalname,
                    parents: [folderId],
                },
                media: {
                    mimeType: "application/octet-stream",
                    body: fileStream,
                },
            });
            console.log(`File uploaded: ${response.data.name}`);
            res.status(200).send(`File uploaded successfully: ${response.data.name}`);
            return response.data.id;
        }
        else {
            console.log("Please provide folderId and filePath in json format");
            res.status(400).send("Please provide folderId and filePath in json format");
            return null;
        }
    } catch (error) {
        console.error("Error during file upload:", error.message);
        return null;
    }
}

export const isFolderShared = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { folderId, destinationFolderId } = req.params;
    try {
        if (folderId && destinationFolderId) {
            const response = await drive.permissions.list({
                fileId: folderId,
                fields: "permissions(id, role, type,emailAddress)",
            });

            const permission = response.data.permissions.find(permission => permission.role === "owner");
            const servicEmail = response.data.permissions.find(permission => permission.emailAddress === "trans-data-988@transdata-442208.iam.gserviceaccount.com");
            console.log(permission);
            const response1 = await drive.permissions.list({
                fileId: destinationFolderId,
                fields: "permissions(id, role, type,emailAddress)",
            });
            const permission1 = response1.data.permissions.find((i) => {
                return (
                    i.emailAddress === permission.emailAddress
                )
            });
            const servicEmail1 = response1.data.permissions.find(permission => permission.emailAddress === "trans-data-988@transdata-442208.iam.gserviceaccount.com");
            console.log(permission1);
            if (permission1 && servicEmail && servicEmail1) {
                res.status(200).send({ message: "Folder is shared to destination folderId" });
                console.log("Folder is shared to destination folderId");
            }
            else {
                res.status(400).send("Folder is not shared to destination folderId. Please share parent account and trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folderId");
                console.log("Folder is not shared to destination folderId. Please share parent account and trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folderId");
            }
        }
        else {
            console.log("Please provide folderId and destinationFolderId");
            res.status(400).send("Please provide folderId and destinationFolderId")
        }
    } catch (error) {
        console.error("Error during folder share check:", error.message);
        res.status(500).send(`Error during folder share check: ${error.message}`);
    }
}
export const deleteFile_fold = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { id } = req.params;
    try {
        const response = await drive.files.get({
            fileId: id
        });
        console.log("@", response.data);
        if (id) {
            const response = await drive.files.delete({
                fileId: id,
            });
            res.status(200).send("File deleted successfully");
            console.log(response.data);
        }
        else {
            console.log("Please provide fileId");
            res.status(400).send("Please provide fileId");
        }
    } catch (error) {
        res.status(500).send(`Error deleting file: ${error.message}`);
        console.error("Error deleting file:", error);
    }

}
export const createFile = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { folderId, fileName } = req.params;
    try {
        if (folderId && fileName) {
            const fileMetadata = {
                'name': fileName,
                parents: [folderId]
            };
            const media = {
                mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                body: fs.createReadStream('text.xlsx')
            };
            const response = await drive.files.create({
                resource: fileMetadata,
                media: media,
                fields: 'id,name'
            });
            res.status(200).send(`File created successfully. FileId: ${response.data.name}`);
            console.log(response.data);
        }
        else {
            res.status(400).send("Please provide folderId and fileName");
            console.log("Please provide folderId and fileName");
        }
    } catch (error) {
        console.error("Error creating file:", error.message);
        res.status(500).send(`Error creating file: ${error.message}`);
    }
}
export const renameFile_fold = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { id, newFileName } = req.params;
    try {
        if (id && newFileName) {
            const fileMetadata = {
                'name': newFileName
            };
            const response = await drive.files.update({
                fileId: id,
                resource: fileMetadata
            });
            res.status(200).send(`File/Folder renamed successfully. FileId: ${response.data.name}`);
            console.log(response.data);
        }
        else {
            res.status(400).send("Please provide fileId and newFileName");
            console.log("Please provide fileId and newFileName");
        }
    } catch (error) {
        console.error("Error renaming file:", error.message);
        res.status(500).send(`Error renaming file: ${error.message}`);
    }

}
export const checkHealth = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { id } = req.params;
    try {
        if (id) {
            const response1 = await drive.files.get({
                fileId: id,
                fields: 'name,mimeType,webViewLink,permissions(id,role,type,emailAddress)'
            });
            //console.log("+++++++++++",response1.data);
            if (response1.data.mimeType === "application/vnd.google-apps.folder") {
                //console.log("Path:",response1.data.webViewLink);
                let totalSize = 0;
                totalSize = await isFoldFile(id, drive, totalSize);
                console.log(`Total size of folder ${response1.data.name}: ${totalSize} bytes`);
                // console.log("Folder type is correct");
                const permission = response1.data.permissions.find((i) => {
                    return (
                        i.emailAddress === "trans-data-988@transdata-442208.iam.gserviceaccount.com"
                    )
                })
                if (permission.emailAddress === "trans-data-988@transdata-442208.iam.gserviceaccount.com") {
                    res.status(200).send({ message: `Folder is healthy and total size of ${response1.data.name} folder is ${totalSize} bytes` });
                    console.log("Folder is healthy");
                }
                else {
                    res.status(404).send({ message: "Folder is not healthy" });
                    console.log("Folder not found");
                }
            }
            else {
                const permission = response1.data.permissions.find((i) => {
                    return (
                        i.emailAddress === "trans-data-988@transdata-442208.iam.gserviceaccount.com"
                    )
                })
                console.log("________________", permission);
                const response = await drive.files.get({
                    fileId: id,
                    fields: 'name,mimeType,modifiedTime,webViewLink,thumbnailLink,size,permissions(id,role,type,emailAddress)'
                });
                console.log(response.data);

                if (response.data && permission.emailAddress === "trans-data-988@transdata-442208.iam.gserviceaccount.com") {
                    res.status(200).send({ message: "File is healthy" });
                }
                else {
                    res.status(404).send({ message: "File not found" });
                }
            }

        }
        else {
            res.status(400).send("Please provide fileId");
            console.log("Please provide fileId");
        }
    } catch (error) {
        console.error("Error checking health of file/folder:", error.message);
        res.status(500).send({ message: `Error checking health of file/folder: ${error.message}` });
    }

}
const isFoldFile = async (id, drive, totalSize) => {
    //console.log("----------------------------------------------------------");
    const response = await drive.files.list({
        q: `'${id}' in parents`,
        fields: 'files(name,id,mimeType,modifiedTime,webViewLink,thumbnailLink,size,permissions(id,role,type,emailAddress))'
    });
    const files = response.data.files;
    //console.log("@",files);

    for (const file of files) {
        if (file.mimeType === "application/vnd.google-apps.folder") {
            console.log(file)
            totalSize = await isFoldFile(file.id, drive, totalSize);
        }
        else {
            console.log(file);
            totalSize += parseInt(file.size);
        }
    }
    return totalSize;
}

export const copyFileWithoutPath = async (req, res) => {
    const drive = google.drive({ version: 'v3', auth });
    const { fileId, destinationFolderId } = req.params;
    if (!fileId || !destinationFolderId) {
        return res.status(400).send({ error: 'fileid and destinationFolderId are required' });
    }
    else {
        try {
            const subFolder2 = await drive.files.get({
                fileId: fileId,
                fields: "id, name, parents,webViewLink",
            });
            const copiedFile = await drive.files.copy({
                fileId: fileId,
                requestBody: {
                    name: subFolder2.data.name,
                    parents: [destinationFolderId],
                    fields: "id, webViewLink, name",
                },

            });
            console.log(copiedFile.data);
            res.status(200).send({ message: "File copied successfully", data: copiedFile.data });
        } catch (err) {
            res.status(500).send({ message: "Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error copying file", error: err.message });
            console.log("Please share trans-data-988@transdata-442208.iam.gserviceaccount.com to destination folder and source file. Error during folder share check:", err);
        }
    }
}