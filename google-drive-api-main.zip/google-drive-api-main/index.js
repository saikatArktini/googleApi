// //require = require('esm')(module);
// import express from 'express';
// import driveRoutes from './routes/crud.route.js';
// import fileRoutes from './routes/fileHandling.js';
// import folderRoutes from './routes/folderHandling.js';
// import swaggerUi from 'swagger-ui-express';
// import fs from 'fs';
// //import swaggerDocument from './swagger/swagger.json';
// //import swagger from './swagger/swagger.json';
// const swaggerDocument = JSON.parse(fs.readFileSync('./swagger/swagger.json', 'utf8'));
// //const swaggerDocument = JSON.parse(JSON.stringify(swagger));
// //import multerConfig from './middlewares/multerconfig.js';
// const app = express();
// app.use(express.json());
// const PORT = 9000;


// // Swagger documentation
//  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// // // Routes
// app.use('/api/drive', driveRoutes);
// app.use('/api/drive/file',fileRoutes );
// app.use('/api/drive/folder', folderRoutes);
// // Start the server
// app.get('/', (req, res) => {
//   res.send('Hello, World!');
// })
// app.listen(PORT, () => {
//   console.log(`Server running at http://localhost:${PORT}`);
//   console.log(`Swagger docs at http://localhost:${PORT}/api-docs`);
// });




import express from 'express';
import driveRoutes from './routes/crud.route.js';
import fileRoutes from './routes/fileHandling.js';
import folderRoutes from './routes/folderHandling.js';
import swaggerUi from 'swagger-ui-express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import jobRoute from "./routes/jobs.route.js"

// Load Swagger JSON file
const swaggerDocument = JSON.parse(fs.readFileSync('./swagger/swagger.json', 'utf8'));

// Create an Express application
const app = express();

app.use(cors())

// CORS setup (allowing all origins for now)
// const allowedOrigins = [
//   'http://localhost:9000',
//   'http://localhost:9000/api-docs',
//   'http://localhost:5173/'
// ];

// app.use(cors({
//   origin: function (origin, callback) {
//     if (!origin) {
//       console.log('Request without Origin header (e.g., local request or Swagger)');
//     } else {
//       console.log(`Request Origin: ${origin}`);
//     }

//     if (!origin || allowedOrigins.includes(origin)) {
//       callback(null, true);
//     } else {
//       callback(new Error('Not allowed by CORS'));
//     }
//   }
// }));


// Middleware to parse JSON requests
app.use(express.json());

// Set up a Swagger endpoint to serve the documentation
app.get('/swagger.json', (req, res) => {
  res.sendFile(path.resolve('./swagger/swagger.json'));
});

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(null, {
  swaggerOptions: {
    url: '/swagger.json' //
  }
}));

// Define API routes
app.use('/api/drive', driveRoutes);
app.use('/api/drive/file', fileRoutes);
app.use('/api/drive/folder', folderRoutes);
app.use('/api/drive/jobs', jobRoute)
app.use('/api/drive/asset', fileRoutes);

// Basic root route
app.get('/', (req, res) => {
  res.send('Hello, World!');
});

// Start the server
const PORT = 9000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`Swagger docs available at http://localhost:${PORT}/api-docs`);
});
